/*
 * Copyright (C) Group 4
 *
 * This file is part of paparazzi
 *
 * paparazzi is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2, or (at your option)
 * any later version.
 *
 * paparazzi is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with paparazzi; see the file COPYING.  If not, see
 * <http://www.gnu.org/licenses/>.
 */
/**
 * @file "modules/green_keeper/green_keeper.c"
 * @author Group 4
 * green keeper makes sure the drone moves forward if green is in front camera
 */

#include <time.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "firmwares/rotorcraft/navigation.h"

#include "generated/flight_plan.h"
#include "modules/computer_vision/colorfilter.h"
#include "modules/green_keeper/green_keeper.h"

#define GREEN_KEEPER_VERBOSE TRUE

#define PRINT(string,...) fprintf(stderr, "[green_keeper->%s()] " string,__FUNCTION__ , ##__VA_ARGS__)
#if GREEN_KEEPER_VERBOSE
#define VERBOSE_PRINT PRINT
#else
#define VERBOSE_PRINT(...)
#endif

uint8_t safeToGoForwards        = FALSE;
int tresholdColorCount          = 5000; // 520 x 240 = 124.800 total pixels
float incrementForAvoidance;
uint16_t trajectoryConfidence   = 5;
float maxDistance               = 2; // was 2.25
uint8_t Turning;
float moveFactor		= 1; // to take care of borders of obstacle zone
bool boolMoveFactor; 	     // movefactor boolean

/*
 * Initialisation function, setting the colour filter, random seed and incrementForAvoidance
 */
void green_keeper_init()
{
  // Initialise the variables of the colorfilter to accept GREEN, http://www.niwa.nu/2013/05/understanding-yuv-values/ is used to determine values for cb and cr for green (test these values!), while luminance is not changed with respect to initial values for orange. 
  
uint8_t color_lum_min = 2; // was 5, later 1
uint8_t color_lum_max = 130; // was 101, later 127
uint8_t color_cb_min  = 8; // was 8, later 47
uint8_t color_cb_max  = 105; // 105, later 122
uint8_t color_cr_min  = 130; // 136, later 110
uint8_t color_cr_max  = 170; // 152, later 138
uint8_t Turning = FALSE;
 

  // Initialise random values
  srand(time(NULL));
  chooseIncrementAvoidance(col_count, tresholdColorCount);
}

/*
 * Function that checks it is safe to move forwards, and then moves a waypoint forward or changes the heading
 */
void green_keeper_periodic()
{
  // Check the amount of green. If this is below a threshold
  // you want to turn a certain amount of degrees
  safeToGoForwards = col_count[3] > tresholdColorCount && col_count[4] > tresholdColorCount && col_count[2] > tresholdColorCount - 1000 && col_count[5] > tresholdColorCount - 1000 && col_count[1] > tresholdColorCount - 4000 && col_count[6] > tresholdColorCount - 4000 && col_count[0] > tresholdColorCount - 4000 && col_count[7] > tresholdColorCount - 4000 ;
  // && col_count[1] > tresholdColorCount - 2000 && col_count[6] > tresholdColorCount - 2000

  //VERBOSE_PRINT("Color_count: %d  threshold: %d safe: %d \n", color_count, tresholdColorCount, safeToGoForwards);
 VERBOSE_PRINT("cnt1 = %d cnt2 = %d cnt3 = %d cnt4 = %d cnt5 = %d cnt6 = %d cnt7 = %d cnt8 = %d \n", col_count[0], col_count[1], col_count[2], col_count[3], col_count[4], col_count[5], col_count[6], col_count[7]);
   
  float moveDistance = fmin(maxDistance, 0.40 * trajectoryConfidence);

  if(safeToGoForwards){
	  Turning = FALSE;
      moveWaypointForward(WP_GOAL, moveFactor * moveDistance);
      moveWaypointForward(WP_TRAJECTORY, moveFactor * 1.25 * moveDistance);
      nav_set_heading_towards_waypoint(WP_GOAL);

      trajectoryConfidence += 2;
  }
  else{
      waypoint_set_here_2d(WP_GOAL);
      waypoint_set_here_2d(WP_TRAJECTORY);
      chooseIncrementAvoidance(col_count, tresholdColorCount);
      increase_nav_heading(&nav_heading, incrementForAvoidance);
      if(trajectoryConfidence > 5){
          trajectoryConfidence -= 4;
      }
      else{
          trajectoryConfidence = 3;
      }
  }
  return;
}

/*
 * Increases the NAV heading. Assumes heading is an INT32_ANGLE. It is bound in this function.
 */
uint8_t increase_nav_heading(int32_t *heading, float incrementDegrees)
{
  struct Int32Eulers *eulerAngles   = stateGetNedToBodyEulers_i();
  int32_t newHeading = eulerAngles->psi + ANGLE_BFP_OF_REAL( incrementDegrees / 180.0 * M_PI);
  // Check if your turn made it go out of bounds...
  INT32_ANGLE_NORMALIZE(newHeading); // HEADING HAS INT32_ANGLE_FRAC....
  *heading = newHeading;
  VERBOSE_PRINT("Increasing heading to %f\n", ANGLE_FLOAT_OF_BFP(*heading) * 180 / M_PI);
  return FALSE;
}

/*
 * Calculates coordinates of a distance of 'distanceMeters' forward w.r.t. current position and heading
 */

uint8_t calculateForwards(struct EnuCoor_i *new_coor, float distanceMeters)
{
  struct EnuCoor_i *pos             = stateGetPositionEnu_i(); // Get your current position
  struct Int32Eulers *eulerAngles   = stateGetNedToBodyEulers_i();
  // Calculate the sine and cosine of the heading the drone is keeping
  float sin_heading                 = sinf(ANGLE_FLOAT_OF_BFP(eulerAngles->psi));
  float cos_heading                 = cosf(ANGLE_FLOAT_OF_BFP(eulerAngles->psi));
  // Now determine where to place the waypoint you want to go to
  new_coor->x                       = pos->x + POS_BFP_OF_REAL(sin_heading * (distanceMeters));
  new_coor->y                       = pos->y + POS_BFP_OF_REAL(cos_heading * (distanceMeters));
  VERBOSE_PRINT("Calculated %f m forward position. x: %f  y: %f based on pos(%f, %f) and heading(%f)\n", distanceMeters, POS_FLOAT_OF_BFP(new_coor->x), POS_FLOAT_OF_BFP(new_coor->y), POS_FLOAT_OF_BFP(pos->x), POS_FLOAT_OF_BFP(pos->y), ANGLE_FLOAT_OF_BFP(eulerAngles->psi)*180/M_PI);
  return FALSE;
}

/*
 * Sets waypoint 'waypoint' to the coordinates of 'new_coor'
 */
uint8_t moveWaypoint(uint8_t waypoint, struct EnuCoor_i *new_coor)
{
  VERBOSE_PRINT("Moving waypoint %d to x:%f y:%f\n", waypoint, POS_FLOAT_OF_BFP(new_coor->x), POS_FLOAT_OF_BFP(new_coor->y));
  waypoint_set_xy_i(waypoint, new_coor->x, new_coor->y);
  return FALSE;
}

/*
 * Check in which zone and adjust moveFactor, this function is not working properly yet.
 *

void setMoveFactor(bool boolmoveFactor)
{ 
  if (boolmoveFactor == TRUE)
	{moveFactor = 1.0;}
  else {moveFactor = 0.5;}

VERBOSE_PRINT("Set waypoints further away by factor %d \n", moveFactor);

} */

/*
 * Calculates coordinates of distance forward and sets waypoint 'waypoint' to those coordinates
 */
uint8_t moveWaypointForward(uint8_t waypoint, float distanceMeters)
{
  struct EnuCoor_i new_coor;
  calculateForwards(&new_coor, distanceMeters);
  moveWaypoint(waypoint, &new_coor);
  return FALSE;
}

/*
 * Sets the variable 'incrementForAvoidance' based on the side with the most green pixels. Furthermore, turn fast (10 deg) or slow (5 deg) based on the amount of green pixels. Lastly, set the turning flag to TRUE, which means the direction will remain constant untill the drone has moved forward again.
 */

uint8_t chooseIncrementAvoidance(uint32_t* arr, int* threshold){  
 if(Turning == FALSE){
	  if (arr[0] + arr[1] + arr[2] < arr[5] + arr[6] + arr[7]){
	    if (2*arr[0] < arr[1]+arr[2]-1000){ incrementForAvoidance = 5;}
	    else {incrementForAvoidance = 10;}
	    VERBOSE_PRINT("Set avoidance increment to: %f\n", incrementForAvoidance);
	  }
	  else if(arr[0] + arr[1] + arr[2] > arr[5] + arr[6] + arr[7]){
	    if (2*arr[7] < arr[5]+arr[6]-1000){ incrementForAvoidance = -5;}
	    else {incrementForAvoidance = -10;}
	    VERBOSE_PRINT("Set avoidance increment to: %f\n", incrementForAvoidance);
	  }
	
	  Turning = TRUE;

 }

  return FALSE;
}

